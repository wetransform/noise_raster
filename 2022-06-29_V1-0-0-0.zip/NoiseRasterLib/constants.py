# -*- coding: utf-8 -*-
##****************************************************************************
## TOOLNAME:    NoiseRasterArcGIS
## QUELLDATEI:  constants.py
## VERSION:     ArcGIS Pro 2.9.2
## ERSTELLT:    Florian Hoffmann (GISCON geo.engineering.gmbh)
## DATUM:       29.06.2022
## VERSION:     1.0.0.0
## VERWENDUNG:  Liste von Konstanten
##****************************************************************************

"""
/***************************************************************************
 NoiseRaster constants
 ***************************************************************************/
"""
import tempfile
import os
import arcpy
from arcpy.sa import RemapRange

# For the arcpy "same dataset name" bug, we altered the final names.
# Shape => added "Vector"
# Raster "Raster"

REPROJECTED_TIF3035 = "final_raster_3035.tif"
REPROJECTED_TMP_TIF3035 = "final_3035_tmp.tif"

REPROJECTED_TIF25832 = "final_raster_25832.tif"

REPROJECTED_SHP3035 = "final_vector_3035.shp"

REPROJECTED_SHP25832 = "final_vector_25832.shp"

arcpySR3035  = arcpy.SpatialReference(3035)
arcpySR25832 = arcpy.SpatialReference(25832)

logger = None

ROOT_TEMP_DIR = tempfile.gettempdir().replace(os.sep, '/')

# Reclassification tables
"""
The selected table values are required input for the "Reclassify by Table" operation. The user selects "Lden" or "Lnight" in the user interface of the tool. 
"Lden" categories are used for daytime noise and "Lnight" are used for night time noise. These value ranges are standards used in noise mapping. 
The input raster is reclassified so that each raster cell gets the same value if it's cell value falls into one of the given ranges. 
This pre-processing step dramatically improves the performance of the vectorization process.
"""
# Lden (GISCON-Format)
reclassifyTableLdenGisconMin = 54.5
reclassifyTableLdenGiscon = [[54.5, 59.49999, 55], [59.5, 64.49999, 60], [64.5, 69.49999, 65], [69.5, 74.49999, 70], [74.5, 9999, 75]]


# Lnight (GISCON-Format)
reclassifyTableLnightGisconMin = 49.5
reclassifyTableLnightGiscon    = [[49.5, 54.49999, 50], [54.5, 59.49999, 55], [59.5, 64.49999, 60], [64.5, 69.49999, 65], [69.5, 9999, 70]]
