# -*- coding: utf-8 -*-
##****************************************************************************
## TOOLNAME:    NoiseRasterArcGIS
## QUELLDATEI:  NoiserasterClass.py
## VERSION:     ArcGIS Pro 2.9.2
## ERSTELLT:    Florian Hoffmann (GISCON geo.engineering.gmbh)
## DATUM:       29.06.2022
## VERSION:     1.0.0.0
## VERWENDUNG:  Implementierung der Funktion innerhalb einer Klasse.
##              Basiert auf dem Code der QGIS-Version
##****************************************************************************
import os
from datetime import datetime
import pathlib
import shutil
import arcpy
import arcpy.sa
import arcpy.ia
import arcpy.conversion
import arcpy.management
from osgeo import gdal, osr
import numpy as np
import NoiseRasterLib.constants as c

class NoiseRasterClass:

    def __init__(self, folderpaths: list, reclassifyTableName:str, out:str, keepTempData:bool):
        self.temp_dir, self.date_time = self.create_temp_directory()
        """
        INPUT: paths to the raster files, name of reclassifyTable, output path
        """
        # check reclassifyTableName
        if(reclassifyTableName == "LDEN"):
            self.useReclassifyTableGiscon = c.reclassifyTableLdenGiscon
            self.useReclassifyTableGisconMin = c.reclassifyTableLdenGisconMin
        elif(reclassifyTableName == "LNIGHT"):
            self.useReclassifyTableGiscon = c.reclassifyTableLnightGiscon
            self.useReclassifyTableGisconMin = c.reclassifyTableLnightGisconMin
        else:
            raise ValueError("reclassifyTableName must be LDEN or LNIGHT and not {}".format(reclassifyTableName))

        self.outputFolder = out
        self.folderpaths = folderpaths
        self.keepTempData = keepTempData

        # Create output-folder if not exists
        pathlib.Path(self.outputFolder).mkdir(parents=True, exist_ok=True)
        
        # Check licence
        checkProdBasic = arcpy.CheckProduct("arcview")
        checkProdStandard = arcpy.CheckProduct("arceditor")
        checkProdAdvanced = arcpy.CheckProduct("arcinfo")

        if checkProdBasic == 'NotLicensed' and checkProdStandard == 'NotLicensed' and checkProdAdvanced == 'NotLicensed':
            raise PermissionError("No ArcGIS license (Basic, Standard, Advanced)")
        arcpy.AddMessage("ArcGIS license available")

    def work_folders(self) :
        """
        OUTPUT: list of list of the checked and reprojected raster files inside the temp folder
        """

        # List of folders with raster-data
        rasterlist = []

        # List of lists (per folder) of reprojected raster-images-paths
        reprojectlist = []

        # List of paths to final results (shape and raster) to add to (current) map
        finalResults = []
    

        # Write progress to console
        arcpy.AddMessage("Creating lists of source raster files...")
    
        # Fill rasterlist array with folderpath(s) 
        for path in self.folderpaths:
            if len(path) != 0:
                rasterlist.append(path)
    
        for path in rasterlist:
            arcpy.AddMessage("Analysing input folder {}".format(path))
            
            rasterfiles = [os.path.join(path, f) for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]
            arcpy.AddMessage("Found {} files".format(len(rasterfiles)))

            # Check file types
            if(not self.validate_source_format(rasterfiles)):
                raise ValueError('File extension is not .asc or .tif')
            
            # Check extent (only log)
            self.check_extent(rasterfiles)

            # Check crs
            if(not self.check_projection(rasterfiles)):
                raise ValueError('Spatial reference system is not defined')

            # Reproject
            reprojectlistSub = self.reproject(rasterfiles)

            # Add list as item
            reprojectlist.append(reprojectlistSub)
        
        # If were here, the files are processed and reprojectlist is filled.            
        # Check if more we have more than one list, do a sound sum if true
        if(len(reprojectlist) >1):
            # sound sum
            # Merge all input noise rasters in each list to create one merged raster, per list            
            arcpy.AddMessage("More than one raster source folder. Merging...")

            mergedlist = self.merge_rasters(reprojectlist, self.temp_dir)

            # Create merged virtual raster with multiple bands for addition
            mergedVRT = self.build_virtual_raster(mergedlist)
            
            # Create masked array for addition which accounts for no data values
            zeroData = self.create_zero_array(mergedVRT)
            
            # Call calculation function
            sound_sum = self.sum_sound_level_3D(zeroData)
            
            # Write energetically added array to raster in GTiff format            
            out_energetic_ras = self.create_raster(sound_sum, mergedVRT, self.outputFolder)
            
            # Set no data value to -99.0
            out_final_ras = self.set_nodata_value(out_energetic_ras)
            
            # Vectorize energetically added raster including all noise sources
            finalShpPath = self.vectorize(out_final_ras)
            
            # Reproject energetically added raster to EPSG:3035
            finalTiffPath = self.reproject_3035(out_final_ras, self.outputFolder)
            
            # Add the results to the return list
            finalResults.append(finalShpPath)
            finalResults.append(finalTiffPath)
        else:
            # only one list
            # Merge all input rasters for a single noise source
            arcpy.AddMessage("Only one raster source folder...")

            out_merged_ras = self.merge_rasters(reprojectlist, self.outputFolder)
            
            # Vectorize raster
            finalShpPath = self.vectorize(out_merged_ras)

            # Reproject raster to EPSG:3035
            finalTiffPath = self.reproject_3035(out_merged_ras, self.outputFolder)
            
            # Add the results to the return list
            finalResults.append(finalShpPath)
            finalResults.append(finalTiffPath)

        # Return the final results (shape + tiff paths)
        arcpy.AddMessage("Return final results: {}".format(finalResults))

        if not self.keepTempData == False:
            arcpy.AddMessage("Removing temp folder...")            
            try:
                shutil.rmtree(self.temp_dir)
            except Exception as ex:
                arcpy.AddError("Exception at deleting temp-folder {}. Message: {}".format(self.temp_dir, ex))

        return finalResults
    
    def create_temp_directory(self):
        """
        Create a sub-directory in the current temp folder to hold intermediate files.
        """

        # Convert date, time to string in format: dd_mm_YY_H_M_S
        datetime_str = datetime.now().strftime("%d_%m_%Y_%H_%M_%S")
        # Create sub directory named 'noise_<current date and time>' in temp folder to collect intermediate files
        os.makedirs(c.ROOT_TEMP_DIR + "/noise_" + datetime_str)
        temp_dir = c.ROOT_TEMP_DIR + "/noise_" + datetime_str + "/"

        return temp_dir, datetime_str

    def validate_source_format(self, srcData: list):
        """
        Check that the file extension of all input rasters is .asc or .tif.
        """

        # Check that the file extension of all input rasters is .asc or .tif
        for srcDs in srcData:
            # Convert to lowercase
            src = srcDs.lower()
            if (src.endswith(".asc")) or (src.endswith(".tif")):
                pass
            else:
                # Write file name to logfile
                arcpy.AddError('EXTENSION NOT ASC OR TIF: Filename: {}'.format(os.path.basename(srcDs)))
                #raise ValueError('File extension is not .asc or .tif')
                return False
        return True

    def check_extent(self, extent_list: list):
        """
        Check extent of each raster is divisible by 100
        """
        # Write progress to console
        arcpy.AddMessage("Checking extent of source rasters...")

        for ds in extent_list:
            # Open dataset
            check_extent = gdal.Open(ds)

            # Get extent of raster
            xmin, xpixel, _, ymax, _, ypixel = check_extent.GetGeoTransform()
            xmin_center = xmin + (xpixel / 2)
            ymax_center = ymax + (abs(ypixel) / 2)

            if (abs(xmin_center % 100) < 0.001) or (abs(ymax_center % 100) < 0.001):
                # Get source file name
                f_name = os.path.basename(ds).split(".")[0]
                # Write file name and extent to logfile
                arcpy.AddMessage('CHECK EXTENT: Filename: {}'.format(str(f_name)))
                arcpy.AddMessage('Pixel value: {}'.format(str(xmin_center)))
                arcpy.AddMessage('Pixel value: {}'.format(str(ymax_center)))
                # Close dataset
                check_extent = None
            else:
                # Close dataset
                check_extent = None
                pass

    def check_projection(self, in_data: list):
        """
        Check for existence of a defined projection in GTiff files
        """
        # Write progress to console
        arcpy.AddMessage("\nChecking CRS of source rasters...")

        for ds in in_data:

            # Check if raster is asc
            # Convert to lowercase
            src = ds.lower()
            if src.endswith(".asc"):
                # Check is passed for asc files because asc files do not contain crs information.
                pass

            # Check crs definition if data is GTiff
            else:

                # Open dataset
                check_ds = gdal.Open(ds)

                # Check projection of source raster
                prj = check_ds.GetProjection()

                if len(prj) == 0:
                    # Get source file name
                    f_name = os.path.basename(ds).split(".")[0]
                    # Write file name to logfile
                    arcpy.AddError('Filename: {}'.format(str(f_name)))
                    return False

                check_ds = None
        return True

    def reproject(self, input_files_path:list):
        """
        Reproject tifs to EPSG:25832. Source crs of GTiff files is read from the data.
        Translate asc files to tifs. Source crs of asc files is assumed to be EPSG:25832.
        Set no data value to -99.0.
        """

        # Write progress to console
        arcpy.AddMessage("Reprojecting source rasters...")

        # List to hold list of reprojected rasters
        reprojectedlist = []

        for input in input_files_path:

            # Get source directory name
            d_path = os.path.dirname(input)
            d_name = os.path.basename(d_path)

            # Get source file name
            f_name = os.path.basename(input).split(".")[0]

            # Check if raster is asc
            # Convert to lowercase
            src = input.lower()
            if src.endswith(".asc"):
                # Translate asc files to tif using EPSG:25832 as defined source crs

                # Create tif raster
                out_tif = self.temp_dir + d_name + "_" + f_name + "_25832.tif"

                # Set translate options
                to = gdal.TranslateOptions(format="GTiff", outputSRS='EPSG:25832', outputType=gdal.GDT_Float32)

                # Convert asc file to tif
                gdal.Translate(out_tif, input, options=to)

                # Read existing no data value(s)
                dst_ds = gdal.Open(out_tif, gdal.GA_Update)
                ndv = dst_ds.GetRasterBand(1).GetNoDataValue()
                newndv = -99.0
                band1 = dst_ds.GetRasterBand(1).ReadAsArray()
                band1[band1 == ndv] = newndv

                # Set no data value for source rasters to -99.0
                dst_ds.GetRasterBand(1).SetNoDataValue(newndv)
                dst_ds.GetRasterBand(1).WriteArray(band1)
                dst_ds = None

                # Add raster list to list of lists
                reprojectedlist.append(out_tif)

                # Close raster
                out_tif = None

            else:
                # File is GTiff
                # Warp GTiff using dataset's defined crs as source crs
            
                # Create reprojected raster
                out_tif = self.temp_dir + d_name + "_" + f_name + "_25832.tif"

                # Open dataset
                check_ds = gdal.Open(input)

                # Check projection of source raster
                prj = check_ds.GetProjection()
                src_srs = osr.SpatialReference(wkt=prj)

                dst_srs = osr.SpatialReference()
                dst_srs.ImportFromEPSG(25832)

                # Reproject rasters to EPSG:25832 in GTiff format, set data type

                #warpOptions = gdal.WarpOptions(format='GTiff', srcSRS=src_srs, dstSRS='EPSG:25832', outputType=gdal.GDT_Float32)
                #gdal.Warp(destNameOrDestDS=out_tif, srcDSOrSrcDSTab=input, options=warpOptions)
                warpOptions = gdal.WarpOptions(format='GTiff', srcSRS=src_srs, dstSRS=dst_srs, outputType=gdal.GDT_Float32)                
                gdal.Warp(destNameOrDestDS=out_tif, srcDSOrSrcDSTab=check_ds, options=warpOptions)

                # Check if the 'Warp' created an output
                if not os.path.exists(out_tif):
                    raise OSError("Temp file {} isn't created  by gdal.Warp".format(out_tif))

                # Read existing no data value(s)
                dst_ds = gdal.Open(out_tif, gdal.GA_Update)
                ndv = dst_ds.GetRasterBand(1).GetNoDataValue()
                newndv = -99.0
                band1 = dst_ds.GetRasterBand(1).ReadAsArray()
                band1[band1 == ndv] = newndv

                # Set no data value for source rasters to -99.0
                dst_ds.GetRasterBand(1).SetNoDataValue(newndv)
                dst_ds.GetRasterBand(1).WriteArray(band1)
                dst_ds = None

                # Add raster list to list of lists
                reprojectedlist.append(out_tif)

                # Close raster
                out_tif = None

        return reprojectedlist

    def reproject_3035(self, in_ras, out_ras):
        """
        Reproject the final output raster to EPSG:3035.
        """

        # Add reprojected tif name and file extension to directory file path.
        out_pth_ext = os.path.join(out_ras, c.REPROJECTED_TIF3035)
        out_pth_ext_tmp = os.path.join(out_ras, c.REPROJECTED_TMP_TIF3035)

        # Write progress to console
        arcpy.AddMessage("Running arcpy.ProjectRaster to reproject final EPSG:25832 raster to final EPSG:3035...")

        # Check if input exist        
        if not os.path.exists(in_ras):
            arcpy.AddError("Final output (EPSG:25832) {} doesn't exist! Warp to EPSG:3035 isn't possible.")

        # Reproject gdal. Is buggy, doesn't throws exceptions and gives no result. Changed to arcpy
        # warpOptions = gdal.WarpOptions(format='GTiff', srcSRS='EPSG:25832', dstSRS='EPSG:3035', outputType=gdal.GDT_Float32)
         # gdal.Warp(destNameOrDestDS=out_pth_ext, srcDSOrSrcDSTab=in_ras, options=warpOptions)
        
        # Delete output and tmp output, if exists
        if os.path.exists(out_pth_ext):
            arcpy.management.Delete(out_pth_ext)
        if os.path.exists(out_pth_ext_tmp):
            arcpy.management.Delete(out_pth_ext_tmp)

        # Reproject with arcpy. 
        # Here we have a little bug. Since there is already a final_3035.shp, arcpy won't allow overwriting the dataset final_3035.tif inside this folder.
        # So we need to save it under an other name and move it afterwards
        # So as a bugfix, we enable overwrite in env and dissable it afterwards
        arcpy.management.ProjectRaster(in_ras, out_pth_ext_tmp, c.arcpySR3035)

        # Rename with arcpy, cause the double-naming problem (final_3035.shp <> final_3035.tif) explicitly set the type to "RasterDataset".
        arcpy.management.Rename(out_pth_ext_tmp, out_pth_ext, "RasterDataset")

        # Calculate statistics
        arcpy.AddMessage("Calculating statistics for raster image...")
        arcpy.CalculateStatistics_management(out_pth_ext)

        # Write progress to console
        if os.path.exists(out_pth_ext):
            arcpy.AddMessage("Script completed.")
        else:
            arcpy.AddError("Couldn't create final output {}".format(out_pth_ext))
        
        return out_pth_ext

    def merge_rasters(self, input_files_path:list, out_pth=None):
        """
        Merge lists of rasters into a single raster or merge a single list of rasters to a single raster.
        """

        # Create list of merged rasters
        merged_ras = []

        if len(input_files_path) > 1:
            counter = 1

            for input in input_files_path:

                # Create merged vrt
                out_vrt = self.temp_dir + str(counter) + "_25832.vrt"

                # Write progress to console
                arcpy.AddMessage("Running GDAL BuildVRT to create merged raster based on list of rasters...")

                # Set vrt options
                gdal.BuildVRT(out_vrt, input, resolution='highest', resampleAlg=gdal.gdalconst.GRA_Max, outputSRS='EPSG:25832', srcNodata=-99.0)

                if not os.path.exists(out_vrt):
                    raise OSError("Temp file {} isn't created  by gdal.Warp".format(out_vrt))

                # Add merged raster to list of merged rasters
                merged_ras.append(out_vrt)

                # Close raster
                out_vrt = None

                # Add 1 to counter
                counter += 1

            return merged_ras

        else:
            """
            Merge only one list of rasters
            """

            # Create merged vrt
            out_vrt = self.temp_dir + "singleList_25832.vrt"

            # Write progress to console
            arcpy.AddMessage("Running GDAL BuildVRT to create merged raster based on list of rasters...")

            # Set vrt options
            gdal.BuildVRT(out_vrt, input_files_path[0], resolution='highest', resampleAlg=gdal.gdalconst.GRA_Max, outputSRS='EPSG:25832', srcNodata=-99.0)

            # Write progress to console
            arcpy.AddMessage("Running GDAL Translate to convert virtual merged raster to tif...")

            # Set translate options
            to = gdal.TranslateOptions(format="GTiff", outputSRS="EPSG:25832", noData=-99.0, outputType=gdal.GDT_Float32)

            # Add tif name and file extension to directory file path.
            out_tif = os.path.join(out_pth, c.REPROJECTED_TIF25832)

            # Convert vrt file to tif
            gdal.Translate(out_tif, out_vrt, options=to)

            return out_tif

    def ReclassifyGiscon(self, in_ds, out_ds):
        """
        Custom reclassify code. Uses gdal, numpy array with comparison
        """

        NoData_value = -99
        reclassMin   = self.useReclassifyTableGisconMin
        reclassTable = self.useReclassifyTableGiscon

        # Copy the src to a temp dst. We are working at the loaded file, so we need to copy before.
        # We work in the temp with float values and need to copy it with int32
        out_tmp_reclass_worker = self.temp_dir + 'reclass_worker_not_int32.tif'
        gdal.Translate(out_tmp_reclass_worker, in_ds)

        # Read existing no data value(s)
        work_ds = gdal.Open(out_tmp_reclass_worker, gdal.GA_Update)
        band1 = work_ds.GetRasterBand(1)
        band1.SetNoDataValue(NoData_value)
        band1Array = band1.ReadAsArray()

        # Set the min    
        band1Array[band1Array < reclassMin] = NoData_value
        # Set all other rules
        for rule in reclassTable:
            valFrom = rule[0]
            valTo = rule[1]
            valSet = rule[2]
            band1Array[(valFrom <= band1Array) & (band1Array <= valTo)] = valSet

        # Convert the array to an integer-array (arcpy RasterToPoly can only use Intere-Raster-Images)
        #band1ArrayInt = np.asarray(band1Array, dtype=int)

        # And save
        #band1.DataType = 5 # set the DataType to 5 Int32 # doesn't work that way
        band1.WriteArray(band1Array)        
        work_ds.FlushCache() # saves to disk
        
        # Copy and transform to Int32. So arcpy.RasterToPolygon can use it
        gdal.Translate(out_ds, work_ds, options=gdal.TranslateOptions(outputType=gdal.GDT_Int32))        

        # Cleanup
        work_ds = None
        band1ArrayInt = None
        band1Array = None
        band1 = None

        return out_ds

    def vectorize(self, in_ds):
        """
        Create polygon for vectorization. Reclassify source input raster.
        Vectorize reclassified raster.
        Reproject polygon to EPSG:3035.
        Everything with arcpy
        """

        # Add shp name and file extension to directory path
        out_poly_pth = os.path.join(self.outputFolder, c.REPROJECTED_SHP25832)

        # If exists, delete
        if os.path.exists(out_poly_pth):
            arcpy.management.Delete(out_poly_pth)
                
        # Reclassification output path (in temp)                
        arcpy.AddMessage("Reclassify by giscon...")
        out_reclass = self.temp_dir + 'reclass.tif'
        self.ReclassifyGiscon(in_ds, out_reclass)

        # Write progress to python console
        arcpy.AddMessage('Running arcpy RasterToPolygon...')
                
        # Vectorize reclassified raster to create polygon noise contours
        arcpy.conversion.RasterToPolygon(in_raster=out_reclass, out_polygon_features=out_poly_pth, 
                                         simplify="NO_SIMPLIFY", raster_field="Value", create_multipart_features="SINGLE_OUTER_PART", max_vertices_per_feature=None)

        # Create a "Noise"-Field and copy the values to it (CalculateField can create fields too)
        arcpy.management.CalculateField(in_table=out_poly_pth, field='Noise', expression="!gridcode!", 
                                        expression_type="PYTHON3", code_block='', field_type="FLOAT", enforce_domains="NO_ENFORCE_DOMAINS")

        # Delete the 'gridcode'-Field
        arcpy.management.DeleteField(in_table=out_poly_pth, drop_field='gridcode')
        # Delete the 'Id'-Field
        arcpy.management.DeleteField(in_table=out_poly_pth, drop_field='Id')

        # Reproject polygon to EPSG:3035
        out_poly_rprj = os.path.join(self.outputFolder, c.REPROJECTED_SHP3035)

        # Delete if output exists
        if os.path.exists(out_poly_rprj):
            arcpy.management.Delete(out_poly_rprj)

        # Reproject polygon with arcpy
        arcpy.management.Project(out_poly_pth, out_poly_rprj, c.arcpySR3035)

        # Read and compare the sr
        out_poly_rprj_sr = arcpy.Describe(out_poly_rprj).spatialReference
        if out_poly_rprj_sr.name ==  c.arcpySR3035.name:
            arcpy.AddMessage("Ouput shape file {} has the correct spatial reference {}".format(out_poly_rprj, out_poly_rprj_sr.name))
        else:
            arcpy.AddError("Ouput shape file {} has the wrong spatial reference {}. Should have: {}".format(out_poly_rprj, out_poly_rprj_sr.name, c.arcpySR3035.name))

        # Define the crc, just to be sure
        #arcpy.management.DefineProjection(out_poly_rprj, c.arcpySR3035)

        return out_poly_rprj

    def build_virtual_raster(self, in_vrt:list):
        """
        Build virtual multi-band raster as input to addition (save in temp-dir)
        """
        # Write progress to python console
        arcpy.AddMessage('Creating multi-band raster...')

        merged_vrt = self.temp_dir + 'allnoise.vrt'

        # Set options
        vrto = gdal.BuildVRTOptions(separate=True)
        gdal.BuildVRT(merged_vrt, in_vrt, options=vrto)

        return merged_vrt

    def create_zero_array(self, in_ds):
        """
        Create array as input to energetic addition.
        """
        # Open dataset
        ds = gdal.Open(in_ds)

        data = ds.ReadAsArray()

        # Create masked array with no data values
        zeroData = np.where(data < 0, 0, data)

        return zeroData

    def sum_sound_level_3D(self, sound_levels: np.array):
        """
        INPUT: array of dimension (m,n,l) - stack of sound levels on a 2D map
        OUTPUT: array of dimension (m,n) - final values of cumulative sound levels on a 2D map

        m: y-nodes on the grid
        n: x-nodes on the grid
        l: no. of sound levels per cell's node

        """
        # Write progress to python console
        arcpy.arcpy.AddMessage('Running energetic addition...')

        if not isinstance(sound_levels, np.ndarray):
            raise TypeError('Input is not an array')

        if len(sound_levels.shape) != 3:
            raise ValueError('Input array not 3D ')

        sound_levels.astype(np.float32)

        l, m, n = sound_levels.shape

        sound_pressures = np.zeros((l, m, n)).astype(np.float32)
        sum_pressures = np.zeros((l, m, n)).astype(np.float32)
        out = np.zeros((l, m, n)).astype(np.float32)

        sound_pressures = np.power(10, 0.1 * sound_levels)
        sum_pressures = np.sum(sound_pressures, axis=0)
        out = np.round_((10 * np.log10(sum_pressures)), decimals=1)

        return out

    def create_raster(self, sound_array:np.ndarray, merged_vrt, out_pth=None):
        """
        Create raster based on energetically added array
        """
        # Write progress to python console
        arcpy.arcpy.AddMessage('Creating energetic raster...')

        # Add tif name and file extension to directory file path.
        out_pth_ext = os.path.join(out_pth, c.REPROJECTED_TIF25832)

        # Get geotranform of merged_vrt
        ds = gdal.Open(merged_vrt)
        geotransform = ds.GetGeoTransform()

        # Get columns and rows of output array
        cols = sound_array.shape[1]
        rows = sound_array.shape[0]

        # Create the output raster
        driver = gdal.GetDriverByName("GTiff")
        dsOut = driver.Create(out_pth_ext, cols, rows, 1, eType=gdal.GDT_Float32)

        # Set affine transformation coefficients from source raster
        dsOut.SetGeoTransform(geotransform)

        # Write the output raster
        dsOut.GetRasterBand(1).WriteArray(sound_array)
        dsOut.GetRasterBand(1).SetNoDataValue(0)

        # Set the crs of output raster
        # TODO Make configurable to support sources with other reference systems
        outRasterSRS = osr.SpatialReference()
        outRasterSRS.ImportFromEPSG(25832)
        dsOut.SetProjection(outRasterSRS.ExportToWkt())

        return out_pth_ext

    def set_nodata_value(self, in_ds):
        """
        Check the existing no data value of raster.
        Set no data value to -99.0
        """

        # Read existing no data value(s)
        dst_ds = gdal.Open(in_ds, gdal.GA_Update)
        ndv = dst_ds.GetRasterBand(1).GetNoDataValue()
        newndv = -99.0
        band1 = dst_ds.GetRasterBand(1).ReadAsArray()
        band1[band1 == ndv] = newndv

        # Set no data value for source rasters to -99.0
        dst_ds.GetRasterBand(1).SetNoDataValue(newndv)
        dst_ds.GetRasterBand(1).WriteArray(band1)

        return in_ds
