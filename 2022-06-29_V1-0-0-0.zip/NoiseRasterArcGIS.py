# -*- coding: utf-8 -*-
##****************************************************************************
## TOOLNAME:    NoiseRasterArcGIS
## QUELLDATEI:  NoiseRasterArcGIS.py
## VERSION:     ArcGIS Pro 2.9.2
## ERSTELLT:    Florian Hoffmann (GISCON geo.engineering.gmbh)
## DATUM:       29.06.2022
## VERSION:     1.0.0.0
## VERWENDUNG:  Auswertung von Rasterbildern (Lärmkartierung) mit Klassifizierung
##              und Vektorisierung.
## BENÖTIGT:    Ordnerpfade zu den Rasterdaten, Formatsdefinition,
##              Ausgabeordner, Info zum Erhalt von Temp-Daten
## BEFEHL:      NoiseRasterArcGIS.py <arrayOfInputFolders> <LDEN|LNIGHT> <outputFolder> <keepTempFolder>
##****************************************************************************

import sys
import os
import arcpy
from importlib import reload
import NoiseRasterLib
import NoiseRasterLib.constants as c
from NoiseRasterLib import NoiseRasterClass

# Exit-codes
SYS_EXIT_OKAY = 0
SYS_EXIT_ERROR_ARGS = 1
SYS_EXIT_ERROR_NO_FINAL_RESULTS = 2
SYS_EXIT_ERROR_NO_CURRENT_MAP_INSTANCE = 3
SYS_EXIT_ERROR_EXCEPTION = 4


# Environment
# gdal.Warp needs a env-var to PROJ_LIB
# Should be under: <pythonFolder>\Library\share\proj
if not os.getenv('PROJ_LIB'):
    # We need to set it
    os.environ['PROJ_LIB'] = sys.exec_prefix + "\\Library\\share\\proj"
    os.environ['PROJ_DEBUG'] = "3"
if not os.getenv('GDAL_DATA'):
    os.environ['GDAL_DATA'] = sys.exec_prefix + "\\Library\\share\\gdal"   


# Reload python files (if some code is changed during ArcGIS Pro runtime)
reload(arcpy)
reload(NoiseRasterLib)
reload(NoiseRasterLib.constants)

def main(inputFolders:list, method:str, outputFolder:str, keepTempData:bool):
    """
    Main entry function for the tool
    """

    # Just some information about the found arguments
    arcpy.AddMessage("Input folders ({})".format(len(inputFolders)))
    for inFold in inputFolders:
        arcpy.AddMessage(inFold)
    arcpy.AddMessage("Selected method: {}".format(method))
    arcpy.AddMessage("Output folder: {}".format(outputFolder))
    arcpy.AddMessage("KeepTempData: {}".format(keepTempData))

    if keepTempData == True:
        arcpy.AddMessage("Temp-folder will NOT be deleted after the process finished.")
    else:
        arcpy.AddMessage("Temp-folder will be deleted after the process finished.")
    
    try:
        # Check if max 3 input folders are given
        if len(inputFolders) > 3:
            arcpy.AddError("No more than 3 input folders allowed.")
            sys.exit(SYS_EXIT_ERROR_ARGS)

        # Create new instance and commit arguments
        noise = NoiseRasterClass.NoiseRasterClass(inputFolders, method, outputFolder, keepTempData)

        # Start the process
        finalResults = noise.work_folders()
        
        # Check if we have a valid result (not null and two paths)
        if finalResults is None or len(finalResults)< 2:
            arcpy.AddWarning("No final results or there are not two final results (shape and tiff)")
            sys.exit(SYS_EXIT_ERROR_NO_FINAL_RESULTS)
        
        # Add the Layers to ArcGIS Pro Map
        addToArcGisPro(finalResults)

    except Exception as ex:
        arcpy.AddError(ex)
        sys.exit(SYS_EXIT_ERROR_EXCEPTION)



def addToArcGisPro(finalResults:list):
    """
    Adds the given paths to the current ArcGIS Pro Map
    """
    try:
        # Add the Layers to Map
        project = None
        try:
            project = arcpy.mp.ArcGISProject("CURRENT")
            arcpy.AddMessage("Found running ArcGIS Project")
        except Exception as e:
            arcpy.AddWarning("No active ArcGIS Pro project found. Message: {}".format(e))
            sys.exit(SYS_EXIT_ERROR_NO_CURRENT_MAP_INSTANCE)
        # Check the project instance
        if project is None:
            sys.exit(SYS_EXIT_ERROR_NO_CURRENT_MAP_INSTANCE)

        # We have a project, get the maps and try the first one
        maps = project.listMaps()
        if len(maps) <= 0:
            sys.exit(SYS_EXIT_ERROR_NO_CURRENT_MAP_INSTANCE)

        curmap = maps[0]
        arcpy.AddMessage("Found maps. Using the first {}".format(curmap.name))

        for fr in finalResults:
            arcpy.AddMessage("Adding result: {}".format(fr))
            curmap.addDataFromPath(fr)
    except Exception as ex:
        arcpy.AddError(ex)
        sys.exit(SYS_EXIT_ERROR_EXCEPTION)


if __name__ == '__main__':
    # __name__ check to make sure, this tool is not included as library
    if (len(sys.argv) != 5):
        arcpy.AddMessage("Check arguments. 4 needed. <arrayOfInputFolders> <LDEN|LNIGHT> <outputFolder> <keepTempFolder>")
        sys.exit(SYS_EXIT_ERROR_ARGS)
    # Convert every array-item from "geoprocessing value object" to string/path
    inputFolders = [str(inFold) for inFold in arcpy.GetParameter(0)]
    method = arcpy.GetParameterAsText(1)
    outputFolder = arcpy.GetParameterAsText(2)
    keepTempFolder = arcpy.GetParameterAsText(3) == "true"

    # call the main-function
    main(inputFolders, method, outputFolder, keepTempFolder)